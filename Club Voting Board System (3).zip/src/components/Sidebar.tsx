import { useState } from 'react';
import { X, RefreshCw, Lock, LogOut, LogIn, CheckCircle, Calendar } from 'lucide-react';
import { PasswordChangeModal } from './PasswordChangeModal';
import { CapacitySettingModal } from './CapacitySettingModal';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  setUser: (user: User | null) => void;
  capacities: { 수?: number; 금?: number };
  onCapacitiesChange: (capacities: { 수?: number; 금?: number }) => void;
  semester: string;
  week: string;
  onSemesterWeekChange: (semester: string, week: string) => void;
}

interface User {
  name: string;
  role: string;
}

export function Sidebar({
  isOpen,
  onClose,
  user,
  setUser,
  capacities,
  onCapacitiesChange,
}: SidebarProps) {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginId, setLoginId] = useState('');
  const [loginPwd, setLoginPwd] = useState('');
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showCapacityModal, setShowCapacityModal] = useState(false);

  const handleLogin = () => setShowLoginModal(true);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginId && loginPwd) {
      setUser({ name: '홍길동', role: '회원' });
      setLoginId('');
      setLoginPwd('');
      setShowLoginModal(false);
      alert('로그인 되었습니다.');
    }
  };

  const handleLogout = () => {
    setUser(null);
    alert('로그아웃 되었습니다.');
  };

  const handleScheduleAdjustment = () => {
    alert('이번주 오픈/마감 조정 페이지로 이동합니다.');
  };

  const handleUpdate = async () => {
    if (!('serviceWorker' in navigator)) {
      alert('이 환경은 Service Worker를 지원하지 않습니다.\n하드 새로고침으로 업데이트하세요.');
      return;
    }
    try {
      const registrations = await navigator.serviceWorker.getRegistrations();
      if (registrations.length === 0) {
        alert('등록된 Service Worker가 없습니다.\n하드 새로고침으로 업데이트하세요.');
        return;
      }
      await Promise.all(registrations.map(reg => reg.update()));
      const waitingReg = registrations.find(reg => reg.waiting);
      if (waitingReg) {
        const confirmed = window.confirm('새 버전이 있습니다. 지금 업데이트하시겠습니까?\n(페이지가 새로고침됩니다)');
        if (confirmed) {
          waitingReg.waiting!.postMessage({ type: 'SKIP_WAITING' });
          waitingReg.addEventListener('statechange', () => {
            if (waitingReg.active) window.location.reload();
          });
        }
      } else {
        alert('이미 최신 버전입니다.');
      }
    } catch (error) {
      console.error('[업데이트] 확인 실패:', error);
      alert('업데이트 확인 중 오류가 발생했습니다.');
    }
  };

  const handleHardRefresh = async () => {
    try {
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map(name => caches.delete(name)));
      }
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map(reg => reg.unregister()));
      }
    } finally {
      window.location.href = window.location.origin + window.location.pathname;
    }
  };

  return (
    <>
      {/* Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-sm shadow-2xl">
            <h3 className="text-lg font-bold text-[#4F6D7A] mb-4">로그인</h3>
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#4F6D7A] mb-1">아이디</label>
                <input
                  type="text"
                  value={loginId}
                  onChange={(e) => setLoginId(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C0D6DB]"
                  placeholder="아이디 입력"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#4F6D7A] mb-1">비밀번호</label>
                <input
                  type="password"
                  value={loginPwd}
                  onChange={(e) => setLoginPwd(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C0D6DB]"
                  placeholder="비밀번호 입력"
                  required
                />
              </div>
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => { setShowLoginModal(false); setLoginId(''); setLoginPwd(''); }}
                  className="flex-1 px-4 py-2 bg-[#C0D6DB] text-[#4F6D7A] rounded-lg hover:bg-[#A8C4CA] transition-colors font-medium"
                >
                  취소
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-[#C0D6DB] text-[#4F6D7A] rounded-lg hover:bg-[#A8C4CA] transition-colors font-medium"
                >
                  로그인
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Password Change Modal */}
      <PasswordChangeModal
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
      />

      {/* Capacity Setting Modal */}
      <CapacitySettingModal
        isOpen={showCapacityModal}
        currentCapacities={capacities}
        onSave={onCapacitiesChange}
        onClose={() => setShowCapacityModal(false)}
      />

      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black/50 z-40 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-full w-80 bg-[#EAEAEA] z-50 transform transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#C8C8C8] pt-[max(16px,env(safe-area-inset-top))]">
          {user ? (
            <div className="flex flex-col">
              <span className="font-bold text-lg text-[#4F6D7A]">{user.name}</span>
              <span className="text-xs text-[#4F6D7A] font-normal">{user.role}</span>
            </div>
          ) : (
            <button
              onClick={handleLogin}
              className="flex items-center gap-2 px-5 py-2.5 bg-[#C0D6DB] text-[#4F6D7A] rounded-lg hover:bg-[#A8C4CA] active:bg-[#90B2B8] transition-colors font-bold shadow-md"
            >
              <LogIn className="w-4 h-4" />
              로그인
            </button>
          )}
          <button
            onClick={onClose}
            className="p-2 hover:bg-[#C0D6DB]/40 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-[#4F6D7A]" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto h-[calc(100%-72px)] p-4 flex flex-col gap-6">
          {/* 일반 섹션 */}
          <div>
            <h3 className="text-xs font-semibold text-[#4F6D7A]/60 uppercase tracking-wider mb-3 px-1">일반</h3>
            <div className="space-y-2">
              <button
                onClick={handleHardRefresh}
                className="w-full flex items-center gap-3 p-3 bg-[#C0D6DB] rounded-lg hover:bg-[#A8C4CA] transition-colors"
              >
                <RefreshCw className="w-5 h-5 text-[#4F6D7A] flex-shrink-0" />
                <span className="text-sm text-[#4F6D7A]">새로고침</span>
              </button>
              <button
                onClick={() => setShowPasswordModal(true)}
                className="w-full flex items-center gap-3 p-3 bg-[#C0D6DB] rounded-lg hover:bg-[#A8C4CA] transition-colors"
              >
                <Lock className="w-5 h-5 text-[#4F6D7A] flex-shrink-0" />
                <span className="text-sm text-[#4F6D7A]">비밀번호 변경</span>
              </button>
            </div>
          </div>

          {/* 임원진 섹션 */}
          <div>
            <h3 className="text-xs font-semibold text-[#4F6D7A]/60 uppercase tracking-wider mb-3 px-1">임원진</h3>
            <div className="space-y-2">
              <button
                onClick={() => setShowCapacityModal(true)}
                className="w-full flex items-center gap-3 p-3 bg-[#C0D6DB] rounded-lg hover:bg-[#A8C4CA] transition-colors"
              >
                <CheckCircle className="w-5 h-5 text-[#4F6D7A] flex-shrink-0" />
                <span className="text-sm text-[#4F6D7A]">운동정원 확정</span>
              </button>
              <button
                onClick={handleScheduleAdjustment}
                className="w-full flex items-center gap-3 p-3 bg-[#C0D6DB] rounded-lg hover:bg-[#A8C4CA] transition-colors"
              >
                <Calendar className="w-5 h-5 text-[#4F6D7A] flex-shrink-0" />
                <span className="text-sm text-[#4F6D7A]">이번주 오픈/마감 조정</span>
              </button>
              <button
                onClick={handleUpdate}
                className="w-full flex items-center gap-3 p-3 bg-[#C0D6DB] rounded-lg hover:bg-[#A8C4CA] transition-colors"
              >
                <RefreshCw className="w-5 h-5 text-[#4F6D7A] flex-shrink-0" />
                <span className="text-sm text-[#4F6D7A]">업데이트</span>
              </button>
            </div>
          </div>

          {/* Spacer */}
          <div className="flex-1" />

          {/* Logout */}
          {user && (
            <button
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 p-3 text-[#4F6D7A] hover:text-[#4F6D7A] hover:bg-[#C0D6DB] rounded-lg transition-colors border border-[#C0D6DB] hover:border-[#A8C4CA]"
            >
              <LogOut className="w-4 h-4" />
              <span className="text-sm">로그아웃</span>
            </button>
          )}
        </div>
      </div>
    </>
  );
}