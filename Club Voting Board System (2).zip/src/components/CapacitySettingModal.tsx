import { useState, useEffect } from 'react';
import { X } from 'lucide-react';

interface CapacitySettingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCapacities: {
    수?: number;
    금?: number;
  };
  onSave: (capacities: {
    수?: number;
    금?: number;
  }) => void;
}

export function CapacitySettingModal({ 
  isOpen, 
  onClose, 
  currentCapacities,
  onSave 
}: CapacitySettingModalProps) {
  const [currentDay, setCurrentDay] = useState<'수' | '금'>('수');
  const [wednesday, setWednesday] = useState('');
  const [friday, setFriday] = useState('');

  useEffect(() => {
    if (isOpen) {
      // 모달이 열릴 때 현재 값으로 초기화
      setWednesday(currentCapacities.수?.toString() || '');
      setFriday(currentCapacities.금?.toString() || '');
    }
  }, [isOpen, currentCapacities]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // 현재 선택된 요일만 저장
    const newCapacities: {
      수?: number;
      금?: number;
    } = {
      ...currentCapacities // 기존 값 유지
    };

    if (currentDay === '수') {
      if (wednesday) {
        newCapacities.수 = parseInt(wednesday);
        alert('수요일 운동정원이 확정되었습니다.');
      } else {
        alert('정원을 입력해주세요.');
        return;
      }
    } else {
      if (friday) {
        newCapacities.금 = parseInt(friday);
        alert('금요일 운동정원이 확정되었습니다.');
      } else {
        alert('정원을 입력해주세요.');
        return;
      }
    }

    onSave(newCapacities);
    onClose();
  };

  const handleClose = () => {
    onClose();
  };

  const currentCapacity = currentDay === '수' ? wednesday : friday;
  const setCurrentCapacity = currentDay === '수' ? setWednesday : setFriday;

  return (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-md shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-gray-900">운동정원 확정</h3>
          <button
            onClick={handleClose}
            className="p-1 hover:bg-gray-100 rounded transition-colors"
          >
            <X className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        <p className="text-sm text-gray-600 mb-4">
          수요일과 금요일을 개별적으로 확정할 수 있습니다.
        </p>

        {/* Day Toggle */}
        <div className="flex gap-2 mb-4">
          <button
            type="button"
            onClick={() => setCurrentDay('수')}
            className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
              currentDay === '수'
                ? 'bg-gray-700 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            수요일
          </button>
          <button
            type="button"
            onClick={() => setCurrentDay('금')}
            className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
              currentDay === '금'
                ? 'bg-gray-700 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            금요일
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {currentDay}요일 운동 정원
            </label>
            <input
              type="number"
              min="0"
              value={currentCapacity}
              onChange={(e) => setCurrentCapacity(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500"
              placeholder="예: 48"
            />
          </div>

          {/* Current Status */}
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
            <p className="text-sm text-gray-600 mb-2">현재 확정된 정원</p>
            <div className="space-y-1">
              <p className="text-sm text-gray-900">
                수요일: <span className="font-bold">{currentCapacities.수 ? `${currentCapacities.수}명` : '미설정'}</span>
              </p>
              <p className="text-sm text-gray-900">
                금요일: <span className="font-bold">{currentCapacities.금 ? `${currentCapacities.금}명` : '미설정'}</span>
              </p>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={handleClose}
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
            >
              취소
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-800 transition-colors font-medium"
            >
              {currentDay}요일 확정
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}