
  # Club Voting Board System

  This is a code bundle for Club Voting Board System. The original project is available at https://www.figma.com/design/RxiR7biBdZEA8C6A9sKjAh/Club-Voting-Board-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  